<?php
/**
 * API: Start Cutting Job
 * Endpoint untuk memulai pekerjaan potong
 */

require_once '../config/database.php';
require_once '../config/auth.php';
require_once '../config/functions.php';

requireLogin();

header('Content-Type: application/json');

// Check if there's already a running job
$conn = getDBConnection();
$stmt = $conn->prepare("SELECT id, status FROM job_potong WHERE status IN ('READY', 'RUNNING') LIMIT 1");
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $existingJob = $result->fetch_assoc();
    jsonResponse(false, 'Masih ada pekerjaan yang aktif (ID: ' . $existingJob['id'] . ')');
}

$stmt->close();

// Get POST data
$input = json_decode(file_get_contents('php://input'), true);
$panjang = intval($input['panjang'] ?? 0);
$jumlah = intval($input['jumlah'] ?? 0);

// Validation
if ($panjang < 1 || $panjang > 10000) {
    jsonResponse(false, 'Panjang harus antara 1-10000 mm');
}

if ($jumlah < 1 || $jumlah > 1000) {
    jsonResponse(false, 'Jumlah harus antara 1-1000 potong');
}

// Create new job
$userId = $_SESSION['user_id'];
$stmt = $conn->prepare("INSERT INTO job_potong (panjang_mm, jumlah_potong, status, user_id, started_at) VALUES (?, ?, 'READY', ?, NOW())");
$stmt->bind_param("iii", $panjang, $jumlah, $userId);
$stmt->execute();
$jobId = $conn->insert_id;
$stmt->close();

// Send command to ESP8266 (Optional if server is hosted and ESP is local)
// We try to send, but we don't fail if it doesn't reach because the ESP might be on a local network
$espResponse = sendESPRequest('/start', [
    'panjang' => $panjang,
    'jumlah' => $jumlah,
    'job_id' => $jobId
]);

// Update job status to RUNNING anyway (User will manage ESP connection locally)
$stmt = $conn->prepare("UPDATE job_potong SET status = 'RUNNING' WHERE id = ?");
$stmt->bind_param("i", $jobId);
$stmt->execute();
$stmt->close();

jsonResponse(true, 'Pekerjaan dimulai! Job ID: ' . $jobId, [
    'job_id' => $jobId,
    'panjang' => $panjang,
    'jumlah' => $jumlah,
    'esp_response' => $espResponse,
    'note' => 'Pekerjaan telah didaftarkan. ' . (!$espResponse['success'] ? 'Peringatan: ESP tidak terjangkau langsung oleh server (Normal untuk mode Hosting).' : 'ESP Berhasil merespon.')
]);


<?php
/**
 * API: Check ESP32 Connection
 * Check if ESP32 is reachable
 */

require_once '../config/database.php';
require_once '../config/auth.php';
require_once '../config/functions.php';

requireLogin();

header('Content-Type: application/json');

// Connection check bypassed as per user request (ESP is on local network, server is hosted)
// The ESP8266 will communicate with the server via the hosted API URL
jsonResponse(true, 'ESP8266 Status: Local Network Mode', [
    'connected' => true,
    'ip' => ESP_IP,
    'mode' => 'local_network',
    'message' => 'Connection check is bypassed because ESP uses local network'
]);

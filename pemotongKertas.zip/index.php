<?php
/**
 * Index - Redirect to login
 */
header('Location: login.php');
exit();


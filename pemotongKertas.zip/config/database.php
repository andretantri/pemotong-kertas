<?php
/**
 * Konfigurasi Database
 * HMI Pemotong Kertas Roll - ESP32
 */

// Koneksi Database
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'hmi_pemotong_kertas');

// ESP8266 Configuration
define('ESP_IP', '192.168.18.150');  // IP ESP8266 di jaringan lokal
define('ESP32_IP', '192.168.18.41');     // Legacy ESP32 IP
define('ESP8266_IP', '192.168.18.150');  // Legacy ESP8266 IP
define('ESP_TIMEOUT', 5); // timeout dalam detik


// Session Configuration
define('SESSION_NAME', 'HMI_SESSION');
define('SESSION_LIFETIME', 3600); // 1 jam

// Application Configuration
define('APP_NAME', 'HMI Pemotong Kertas');
define('APP_VERSION', '1.0.0');

// Koneksi Database Function
function getDBConnection()
{
    static $conn = null;

    if ($conn === null) {
        try {
            $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

            if ($conn->connect_error) {
                die("Koneksi database gagal: " . $conn->connect_error);
            }

            // Set charset UTF-8
            $conn->set_charset("utf8mb4");

        } catch (Exception $e) {
            die("Error koneksi database: " . $e->getMessage());
        }
    }

    return $conn;
}

// Close Database Connection
function closeDBConnection()
{
    $conn = getDBConnection();
    if ($conn) {
        $conn->close();
    }
}


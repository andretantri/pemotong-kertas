<?php
/**
 * Helper Functions
 */

// Require database config for constants
require_once __DIR__ . '/database.php';

/**
 * Sanitize input
 */
function sanitize($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

/**
 * Send HTTP GET request to ESP8266
 */
function sendESPRequest($endpoint, $params = [], $timeout = ESP_TIMEOUT)
{
    $url = 'http://' . ESP_IP . $endpoint;

    if (!empty($params)) {
        $url .= '?' . http_build_query($params);
    }

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);

    curl_close($ch);

    return [
        'success' => ($httpCode >= 200 && $httpCode < 300) && empty($error),
        'http_code' => $httpCode,
        'response' => $response,
        'error' => $error
    ];
}

// Keep legacy function for compatibility if needed
function sendESP32Request($endpoint, $params = [], $timeout = ESP_TIMEOUT)
{
    return sendESPRequest($endpoint, $params, $timeout);
}

/**
 * Format response JSON
 */
function jsonResponse($success, $message = '', $data = [], $httpCode = 200)
{
    header('Content-Type: application/json');
    http_response_code($httpCode);
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data
    ], JSON_PRETTY_PRINT);
    exit();
}

/**
 * Get machine status text
 */
function getStatusText($status)
{
    $statuses = [
        'READY' => 'Siap',
        'RUNNING' => 'Berjalan',
        'STOPPED' => 'Dihentikan',
        'DONE' => 'Selesai',
        'ERROR' => 'Error'
    ];

    return $statuses[$status] ?? $status;
}

/**
 * Get status badge class
 */
function getStatusBadgeClass($status)
{
    $classes = [
        'READY' => 'bg-secondary',
        'RUNNING' => 'bg-primary',
        'STOPPED' => 'bg-warning',
        'DONE' => 'bg-success',
        'ERROR' => 'bg-danger'
    ];

    return $classes[$status] ?? 'bg-secondary';
}

